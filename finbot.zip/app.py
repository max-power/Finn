import chainlit as cl
from langchain.schema.runnable.config import RunnableConfig
from finn import Finn

@cl.on_chat_start
async def on_chat_start():
    runnable = Finn().agent
    cl.user_session.set("runnable", runnable)

@cl.on_message
async def on_message(message: cl.Message):
    runnable = cl.user_session.get("runnable")
    runnable_config = RunnableConfig(callbacks=[cl.AsyncLangchainCallbackHandler(
        stream_final_answer=True,
        answer_prefix_tokens=["Final", "Answer"]
    )])

    msg = cl.Message(content="")
    await msg.send()
    
    response = await runnable.ainvoke({"input": message.content}, config=runnable_config)
    await msg.stream_token(response["output"])
    await msg.send()


